namespace NuGetGallery.Configuration;
public sealed class KeyVaultOptions
{
 public const string SectionName="KeyVault"; public string VaultName {get;set;}="";
 public bool UseManagedIdentity {get;set;} public string ClientId {get;set;}="";
 public string CertificateThumbprint {get;set;}="";
}
