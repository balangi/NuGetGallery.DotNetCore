using Microsoft.AspNetCore.StaticFiles;

namespace NuGetGallery.Hosting;

/// <summary>Serves only files under {ContentRoot}/Public (legacy Rewrite Public File behavior).</summary>
public sealed class PublicFileMiddleware
{
    private readonly RequestDelegate _next;
    private readonly string _publicRoot;
    private readonly FileExtensionContentTypeProvider _contentTypes = new();
    public PublicFileMiddleware(RequestDelegate next, IWebHostEnvironment env)
    {
        _next = next;
        _publicRoot = Path.GetFullPath(Path.Combine(env.ContentRootPath, "Public")) + Path.DirectorySeparatorChar;
    }
    public async Task InvokeAsync(HttpContext context)
    {
        if (HttpMethods.IsGet(context.Request.Method) || HttpMethods.IsHead(context.Request.Method))
        {
            var relative = context.Request.Path.Value?.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
            if (!string.IsNullOrEmpty(relative))
            {
                var candidate = Path.GetFullPath(Path.Combine(_publicRoot, relative));
                if (candidate.StartsWith(_publicRoot, StringComparison.OrdinalIgnoreCase) && File.Exists(candidate))
                {
                    if (!_contentTypes.TryGetContentType(candidate, out var type)) type = "application/octet-stream";
                    context.Response.ContentType = type;
                    var info = new FileInfo(candidate);
                    context.Response.ContentLength = info.Length;
                    if (!HttpMethods.IsHead(context.Request.Method)) await context.Response.SendFileAsync(candidate);
                    return;
                }
            }
        }
        await _next(context);
    }
}
