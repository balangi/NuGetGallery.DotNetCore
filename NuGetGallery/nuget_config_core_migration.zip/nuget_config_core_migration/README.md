# بسته مهاجرت NuGetGallery از ASP.NET Framework به ASP.NET Core 8/9

این پوشه نمونه‌ای ساخت‌یافته برای انتقال تنظیمات ریشه‌ی Web.config ارائه می‌کند؛ تبدیل مکانیکیِ یک فایل Web.config به فایل متناظر Core ممکن نیست، چون بسیاری از ماژول‌های System.Web دیگر وجود ندارند و باید در middleware، سرویس‌ها یا خود برنامه بازپیاده‌سازی شوند. فایل‌های پیکربندی شامل secret واقعی نیستند. سه رشته اتصالِ موجود در ورودی فقط به‌صورت مقادیر redacted با پیشوند `secret-...` ارائه شده‌اند؛ بنابراین جای آن‌ها در فایل خروجی خالی است و باید از Secret Manager/متغیر محیطی/Key Vault تزریق شوند.

## فایل‌ها

- `appsettings.json`: تنظیمات عمومی با بخش‌های ConnectionStrings، Gallery، AzureServiceBus، Auth، KeyVault، PackageDelete، FederatedCredential، Logging و ApplicationInsights.
- `appsettings.Development.json`: overrideهای محیط توسعه (با `ASPNETCORE_ENVIRONMENT=Development`). در Core فایل `appsettings.Aspire.config` یا ویژگی `file=` در appSettings خودکار خوانده نمی‌شود.
- `NuGetGalleryConfigurationOptions.cs`، `AuthOptions.cs`، `AzureServiceBusOptions.cs`، `KeyVaultOptions.cs`: مدل‌های strongly typed برای bind کردن.
- `ProgramConfigurationExtensions.cs` و `Program.cs.example`: نمونه ثبت سرویس‌ها و ترتیب pipeline؛ کد را با نام‌فضاها و سرویس‌های واقعی برنامه ادغام کنید.
- `iisRewriteRules.xml`: قواعد قابل‌اجرا توسط `Microsoft.AspNetCore.Rewrite` و `web.config`: فقط تنظیمات IIS/ANCM و filtering.
- `PublicFileMiddleware.cs`: بازسازی امن قاعده Public؛ مسیرهای خارج از Public رد می‌شوند.

## چرا بخش‌های قدیمی حذف شدند؟

`assemblyBinding` و `bindingRedirect` متعلق به loader اسمبلی‌های .NET Framework هستند. در .NET 8/9 وابستگی‌ها از NuGet و فایل‌های `.deps.json`/`.runtimeconfig.json` حل می‌شوند؛ تعارض نسخه را با pin/upgrade کردن پکیج‌ها و توافق نسخه‌های compile-time حل کنید، نه binding redirect.

`system.web` شامل ASP.NET MVC 5/Web Forms، HttpModules، HttpHandlers، machineKey، session و قواعد compilation بود. ASP.NET Core از Kestrel و pipeline مبتنی بر middleware استفاده می‌کند؛ cookie/authentication، خطا، session، فشرده‌سازی، static files و محدودیت بدنه باید با سرویس‌ها و middleware معادل پیاده‌سازی شوند. `machineKey` قدیمی قابل انتقال مستقیم نیست؛ برای Data Protection از `AddDataProtection()` و ذخیره‌سازی پایدار/اشتراکی کلیدها (مثلاً Blob/Key Vault با ACL و رمزگذاری) استفاده کنید.

`system.serviceModel` در این برنامه تنظیم WCF و extensionهای قدیمی Azure Service Bus را ثبت می‌کرد. ASP.NET Core این config sectionها را نمی‌خواند. برای سرویس‌های SOAP/WCF، سازگاری و کتابخانه مناسب .NET جدید را جدا ارزیابی کنید؛ برای Service Bus از SDK مدرن و گزینه‌های `AzureServiceBus`/هویت مدیریت‌شده استفاده و صف/Topicها را در DI ثبت کنید.

بخش `entityFramework` مخصوص EF6 است و خودبه‌خود به EF Core تبدیل نمی‌شود. در صورت مهاجرت به EF Core، provider مناسب (مثلاً Microsoft.EntityFrameworkCore.SqlServer)، DbContext، migrationها و رفتارهای query را جداگانه بررسی کنید؛ connection string صرفاً در `ConnectionStrings` نگهداری می‌شود. اگر موقتاً EF6 نگه داشته شود، پشتیبانی و محدودیت‌های نسخه هدف را مستقل اعتبارسنجی کنید.

## تفکیک مسئولیت تنظیمات

1. `appsettings*.json` پیکربندی برنامه و مقدارهای غیرمحرمانه را نگه می‌دارد؛ override محیطی با env varهایی مانند `ConnectionStrings__GallerySqlServer`، `Auth__MicrosoftAccount__ClientSecret` و `AzureServiceBus__Validation__ConnectionString` ممکن است. کلید secret را commit نکنید. `dotnet user-secrets` برای توسعه و Key Vault/managed identity یا secret store امن برای استقرار مناسب است.
2. `web.config` اینجا فقط برای IIS و ASP.NET Core Module V2 است، نه تنظیم عمومی برنامه. ANCM برنامه را درون/بیرون پردازش میزبانی می‌کند. نمونه خواسته‌شده با `hostingModel="inprocess"` است؛ در انتشار معمولی SDK ممکن است `web.config` را خودکار تولید کند، بنابراین تنظیمات deployment را با publish نهایی ادغام و از overwrite ناخواسته جلوگیری کنید.
3. Kestrel و FormOptions در C# محدودیت بدنه و multipart را تنظیم می‌کنند؛ middleware مسئول URL rewrite، forwarded headers و security headers است. به `UseForwardedHeaders` فقط از proxyهای قابل اعتماد اجازه دهید و `KnownProxies`/`KnownNetworks` را برای محیط واقعی تعریف کنید؛ اعتماد به هر `X-Forwarded-*` ریسک جعل scheme/IP دارد.

## بارگذاری ۲۵۰ MB و طول Query

- IIS: `maxAllowedContentLength="262144000"` بایت (۲۵۰ MiB) و `maxQueryString="12000"` در requestFiltering تنظیم شده است. محدودیت‌های reverse proxy/load balancer/WAF نیز باید حداقل به اندازه نیاز باشند.
- برنامه: `KestrelServerLimits.MaxRequestBodySize` و `FormOptions.MultipartBodyLengthLimit` در نمونه برابر 262,144,000 بایت هستند. محدودیت endpoint-specific، antiforgery، timeout و فضای موقت را نیز با نیاز واقعی هماهنگ کنید.
- `maxQueryString` یک محدودیت IIS است؛ Kestrel گزینه‌ای با همان نام ندارد. Kestrel `MaxRequestLineSize` کل request line را محدود می‌کند (پیش‌فرض معمولاً ۸ KiB) و query بخشی از آن است. اگر query تا 12,000 نویسه لازم است، Kestrel را متناسب (مثلاً دست‌کم 16 KiB، پس از threat review) پیکربندی کنید؛ این مقدار معادل دقیق IIS نیست و باید روی proxy و Kestrel آزمون شود.

## اتصال SQL و Azure Key Vault

نام‌های Core در JSON به شکل `ConnectionStrings:GallerySqlServer` و مانند آن است. از `IConfiguration.GetConnectionString(...)` معمولاً برای ConnectionStrings استفاده می‌شود، اما کلیدهای نمونه با نام‌های اختصاصی `GallerySqlServer` و غیره هستند (نه `GetConnectionString("Gallery")`). رشته‌ها را با env vars یا secret provider override کنید و provider SQL را در DbContext/سرویس ثبت نمایید.

`AddGalleryKeyVault()` نمونه‌ای اختیاری است و در صورت `KeyVault:VaultName` و `UseManagedIdentity=true`، پیکربندی secrets را از `https://{vault}.vault.azure.net/` بارگذاری می‌کند. پکیج `Azure.Extensions.AspNetCore.Configuration.Secrets` و `Azure.Identity` لازم است. برای محیط واقعی به Managed Identity و حداقل دسترسی ترجیح بدهید؛ `ClientId` صرفاً user-assigned identity را مشخص می‌کند. JSON `KeyVault` اطلاعات انتخاب هویت است، نه خود رازها. اگر نام secrets در Vault به شکل `--` باشد، mapping به `:` را بررسی کنید. ترتیب افزودن provider مهم است: providerهای بعدی مقدار قبلی را override می‌کنند. کد نمونه باید قبل از `Build()` اجرا شود.

Application Insights نیازمند پکیج `Microsoft.ApplicationInsights.AspNetCore` و connection string معتبر است؛ از connection string به‌جای instrumentation key در استقرارهای جدید استفاده کنید. تنظیمات `Logging` در سطح provider قابل override است.

## URL Rewrite و نکات مهاجرت

`iisRewriteRules.xml` قواعد Canonicalize Domain Name، preview، legacy feed root، legacy icon، سه تغییر نام DotNetFramework، Curated Feed Download (عدم تغییر) و Curated Feed را دارد. Rewrite middleware باید با پکیج `Microsoft.AspNetCore.Rewrite` نصب و قبل از endpoint routing قرار گیرد. در تنظیم نمونه، HTTPS دائمی فرض شده؛ پیکربندی قدیمی پروتکل را براساس HTTPS IIS می‌ساخت. پشت TLS terminator، forwarded headers و تنظیم canonical redirect را قبل از production تست کنید.

`Rewrite Public File` با XML قابل‌حمل نیست چون شرط `{APPL_PHYSICAL_PATH}` اختصاصی IIS است؛ به `PublicFileMiddleware` امن منتقل شده است. `Artifactory` با `CustomResponse` هم قابلیت استاندارد Rewrite middleware نیست و در middleware نمونه به پاسخ 400 تبدیل شده است. قواعد و regexها را با route واقعی و query stringهای قبلی regression-test کنید. فایل‌های `Content`/`Scripts`/`Public` را تنها پس از بررسی امنیتی سرو کنید؛ پیکربندی قدیمی به‌صراحت static file handler عمومی را حذف کرده بود تا package idهای شامل پسوندهایی مانند `.config` بی‌خطر باقی بمانند. `UseStaticFiles()` پیش‌فرض را در پروژه واقعی با مسیر و مجوزهای دقیق محدود کنید.

## چک‌لیست پیش از انتشار

- همه مقادیر خالی و اسرار را با environment/secret provider مناسب جایگزین کنید؛ به‌ویژه SQL، storage، Service Bus، OAuth و reCAPTCHA.
- تنظیم‌های feature/زمانی و مقادیر محیطی را با نمونه اصلی بازبینی کنید؛ این artifact تنظیمات معادلِ اسکلت است، نه تبدیل منطق اپلیکیشن قدیمی.
- NuGet packages، endpointهای legacy، authentication flows، Data Protection، EF، WCF/Service Bus و حذف/خطاهای HTTP را مستقل مهاجرت دهید.
- Rewrite، upload بزرگ، query بزرگ، static-file traversal، security headers، proxy و health checks را در staging با آزمون integration ارزیابی کنید.
- HSTS فقط روی HTTPS عمومی فعال است؛ مدت و includeSubDomains را پس از بررسی دامنه اعمال کنید. Content Security Policy در ورودی از CSP report URI داشت و نیازمند policy برنامه است.
