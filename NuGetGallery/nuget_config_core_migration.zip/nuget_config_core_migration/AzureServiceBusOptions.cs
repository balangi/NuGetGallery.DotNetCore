namespace NuGetGallery.Configuration;
public sealed class AzureServiceBusOptions
{
 public const string SectionName="AzureServiceBus"; public string ManagedIdentityClientId {get;set;}="";
 public ServiceBusTopicOptions AccountDeleter {get;set;}=new(); public ServiceBusTopicOptions StagingPromotion {get;set;}=new();
 public ServiceBusTopicOptions Validation {get;set;}=new(); public ServiceBusTopicOptions SymbolsValidation {get;set;}=new();
 public ServiceBusTopicOptions EmailPublisher {get;set;}=new();
}
public sealed class ServiceBusTopicOptions { public string ConnectionString {get;set;}=""; public string TopicName {get;set;}=""; }
