namespace NuGetGallery.Configuration;

// Bind root sections by their matching names. Secrets belong in env vars/Key Vault, never source control.
public sealed class NuGetGalleryConfigurationOptions
{
    public const string SectionName = "Gallery";
    public string StorageType { get; set; } = "FileSystem";
    public AzureStorageOptions AzureStorage { get; set; } = new();
    public bool AzureStorageReadAccessGeoRedundant { get; set; }
    public TimeSpan FeatureFlagsRefreshInterval { get; set; } = TimeSpan.FromMinutes(1);
    public bool AdminPanelEnabled { get; set; } = true;
    public bool AdminPanelDatabaseAccessEnabled { get; set; }
    public bool AdminApiEnabled { get; set; }
    public string AdminApiAudience { get; set; } = "";
    public string AdminApiAllowedCallers { get; set; } = "";
    public bool AdminApiTestModeEnabled { get; set; }
    public bool AsynchronousPackageValidationEnabled { get; set; }
    public bool BlockingAsynchronousPackageValidationEnabled { get; set; }
    public bool SelfServiceAccountDeleteEnabled { get; set; }
    public TimeSpan AsynchronousPackageValidationDelay { get; set; } = TimeSpan.FromSeconds(5);
    public TimeSpan ValidationExpectedTime { get; set; } = TimeSpan.FromMinutes(50);
    public string Environment { get; set; } = "Production";
    public string WarningBanner { get; set; } = "";
    public string SiteRoot { get; set; } = "https://www.nuget.org";
    public string SupportEmailSiteRoot { get; set; } = "https://www.nuget.org";
    public string AppInsightsInstrumentationKey { get; set; } = "";
    public int AppInsightsSamplingPercentage { get; set; } = 100;
    public int AppInsightsHeartbeatIntervalSeconds { get; set; } = 60;
    public string FileStorageDirectory { get; set; } = "~/App_Data/Files";
    public string[] ForceSslExclusion { get; set; } = [];
    public string Brand { get; set; } = "NuGet Gallery";
    public bool RequireSSL { get; set; } = true;
    public bool AutoUpdateSearchIndex { get; set; } = true;
    public Dictionary<string, bool> Feature { get; set; } = new();
}
public sealed class AzureStorageOptions
{
    public string Auditing { get; set; } = ""; public string UserCertificates { get; set; } = "";
    public string Content { get; set; } = ""; public string Errors { get; set; } = "";
    public string Packages { get; set; } = ""; public string FlatContainer { get; set; } = "";
    public string Statistics { get; set; } = ""; public string Uploads { get; set; } = "";
    public string Revalidation { get; set; } = ""; public string StatisticsAlternate { get; set; } = "";
}
public sealed class ConnectionStringOptions
{
    public const string SectionName = "ConnectionStrings";
    public string GallerySqlServer { get; set; } = "";
    public string GallerySupportRequestSqlServer { get; set; } = "";
    public string GalleryValidationSqlServer { get; set; } = "";
}
public sealed class PackageDeleteOptions
{
    public bool AllowUsersToDeletePackages { get; set; }
    public int? MaximumDownloadsForPackageId { get; set; }
    public int? StatisticsUpdateFrequencyInHours { get; set; }
    public int? HourLimitWithMaximumDownloads { get; set; }
    public int? MaximumDownloadsForPackageVersion { get; set; }
}
public sealed class FederatedCredentialOptions
{
    public bool EnableTokenApi { get; set; } public string EntraIdAudience { get; set; } = "";
    public TimeSpan ShortLivedApiKeyDuration { get; set; } = TimeSpan.FromMinutes(20);
    public string NuGetAudience { get; set; } = "";
}
