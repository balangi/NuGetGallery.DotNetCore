using Azure.Identity;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Rewrite;
using NuGetGallery.Configuration;

namespace NuGetGallery.Hosting;

public static class ProgramConfigurationExtensions
{
    public const long MaxUploadBytes = 262_144_000; // 250 MiB

    public static WebApplicationBuilder AddGalleryConfiguration(this WebApplicationBuilder builder)
    {
        var c = builder.Configuration;
        builder.Services.AddOptions<NuGetGalleryConfigurationOptions>().Bind(c.GetSection("Gallery")).ValidateOnStart();
        builder.Services.AddOptions<ConnectionStringOptions>().Bind(c.GetSection("ConnectionStrings")).ValidateOnStart();
        builder.Services.AddOptions<AuthOptions>().Bind(c.GetSection(AuthOptions.SectionName)).ValidateOnStart();
        builder.Services.AddOptions<AzureServiceBusOptions>().Bind(c.GetSection(AzureServiceBusOptions.SectionName)).ValidateOnStart();
        builder.Services.AddOptions<KeyVaultOptions>().Bind(c.GetSection(KeyVaultOptions.SectionName)).ValidateOnStart();
        builder.Services.AddOptions<PackageDeleteOptions>().Bind(c.GetSection("PackageDelete")).ValidateOnStart();
        builder.Services.AddOptions<FederatedCredentialOptions>().Bind(c.GetSection("FederatedCredential")).ValidateOnStart();

        builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = MaxUploadBytes);
        builder.Services.Configure<FormOptions>(o =>
        {
            o.MultipartBodyLengthLimit = MaxUploadBytes;
            o.ValueLengthLimit = 16 * 1024 * 1024;
            o.MultipartHeadersLengthLimit = 64 * 1024;
        });
        builder.Services.AddApplicationInsightsTelemetry(); // NuGet: Microsoft.ApplicationInsights.AspNetCore
        return builder;
    }

    // Optional: call after AddGalleryConfiguration and before Build when VaultName is configured.
    // Requires Azure.Extensions.AspNetCore.Configuration.Secrets + Azure.Identity packages.
    public static WebApplicationBuilder AddGalleryKeyVault(this WebApplicationBuilder builder)
    {
        var vault = builder.Configuration.GetSection(KeyVaultOptions.SectionName).Get<KeyVaultOptions>();
        if (vault is { UseManagedIdentity: true } && !string.IsNullOrWhiteSpace(vault.VaultName))
        {
            var credential = string.IsNullOrWhiteSpace(vault.ClientId)
                ? new DefaultAzureCredential()
                : new DefaultAzureCredential(new DefaultAzureCredentialOptions { ManagedIdentityClientId = vault.ClientId });
            builder.Configuration.AddAzureKeyVault(new Uri($"https://{vault.VaultName}.vault.azure.net/"), credential);
        }
        return builder;
    }

    public static WebApplication UseGalleryPipeline(this WebApplication app)
    {
        app.UseForwardedHeaders(new ForwardedHeadersOptions
        {
            ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
            // Configure KnownProxies/KnownNetworks for the actual ingress before deployment.
        });
        if (!app.Environment.IsDevelopment()) app.UseHsts();
        app.Use(async (context, next) =>
        {
            context.Response.OnStarting(() =>
            {
                context.Response.Headers["X-Frame-Options"] = "DENY";
                context.Response.Headers["X-Content-Type-Options"] = "nosniff";
                context.Response.Headers.Remove("X-Powered-By");
                return Task.CompletedTask;
            });
            if (context.Request.Path.StartsWithSegments("/org") &&
                context.Request.Headers.UserAgent.ToString().StartsWith("Artifactory/", StringComparison.OrdinalIgnoreCase))
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                await context.Response.WriteAsync("We are not a Maven repository");
                return;
            }
            await next();
        });
        app.UseMiddleware<PublicFileMiddleware>(); // Implements legacy Rewrite Public File safely.
        var rules = Path.Combine(app.Environment.ContentRootPath, "iisRewriteRules.xml");
        if (File.Exists(rules)) app.UseRewriter(new RewriteOptions().AddIISUrlRewrite(app.Environment.ContentRootFileProvider, "iisRewriteRules.xml"));
        return app;
    }
}
