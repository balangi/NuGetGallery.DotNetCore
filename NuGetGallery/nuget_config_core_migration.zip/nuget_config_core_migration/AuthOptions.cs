namespace NuGetGallery.Configuration;
public sealed class AuthOptions
{
 public const string SectionName="Auth";
 public LocalUserAuthOptions LocalUser {get;set;}=new(); public EnabledAuthOptions ApiKey {get;set;}=new();
 public MicrosoftAccountAuthOptions MicrosoftAccount {get;set;}=new();
 public AzureAdV2AuthOptions AzureActiveDirectoryV2 {get;set;}=new();
 public AzureAdAuthOptions AzureActiveDirectory {get;set;}=new();
}
public class EnabledAuthOptions { public bool Enabled {get;set;} }
public sealed class LocalUserAuthOptions:EnabledAuthOptions { }
public sealed class MicrosoftAccountAuthOptions:EnabledAuthOptions { public string ClientId {get;set;}=""; public string ClientSecret {get;set;}=""; }
public sealed class AzureAdV2AuthOptions:EnabledAuthOptions { public string TenantId {get;set;}="common"; public string ClientId {get;set;}=""; }
public sealed class AzureAdAuthOptions:EnabledAuthOptions { public string ClientId {get;set;}=""; public string Authority {get;set;}=""; public string Issuer {get;set;}=""; public bool ShowOnLoginPage {get;set;} }
